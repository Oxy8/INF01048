# Integrantes

Eduardo Fonseca da Silva - 00577262 - Turma B  
Estevan Kuster - 00334328 - Turma B  
Pedro de Sene Bavaresco - 00333563 - Turma B  

