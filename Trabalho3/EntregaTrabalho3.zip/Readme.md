# Integrantes

Eduardo Fonseca da Silva - 00577262 - Turma B  
Estevan Kuster - 00334328 - Turma B  
Pedro de Sene Bavaresco - 00333563 - Turma B  

# Estatísticas de execução A*
Para o estado "2_3541687"

## Hamming:
  - Nós expandidos: 13506
  - Tempo decorrido: 0.0650 segundos
  - Custo da solução: 23 ações

## Manhattan:
  - Nós expandidos: 1830
  - Tempo decorrido: 0.0088 segundos
  - Custo da solução: 23 ações